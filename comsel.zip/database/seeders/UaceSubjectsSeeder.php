<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class UaceSubjectsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
